/**
 * 
 */
/**
 * 
 */
module OlimpiadasSOLID {
}