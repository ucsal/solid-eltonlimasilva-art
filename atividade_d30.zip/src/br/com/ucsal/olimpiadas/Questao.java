package br.com.ucsal.olimpiadas;

import java.util.Arrays;

public class Questao {
    private long id;
    private long provaId;
    private String enunciado;
    private String[] alternativas = new String[5];
    private char alternativaCorreta;
    private String fenInicial;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getProvaId() { return provaId; }
    public void setProvaId(long provaId) { this.provaId = provaId; }

    public String getEnunciado() { return enunciado; }
    public void setEnunciado(String enunciado) { this.enunciado = enunciado; }

    public String[] getAlternativas() { return alternativas; }
    public void setAlternativas(String[] alternativas) {
        if (alternativas == null || alternativas.length != 5)
            throw new IllegalArgumentException();
        this.alternativas = Arrays.copyOf(alternativas, 5);
    }

    public char getAlternativaCorreta() { return alternativaCorreta; }
    public void setAlternativaCorreta(char alternativaCorreta) {
        this.alternativaCorreta = Character.toUpperCase(alternativaCorreta);
    }

    public boolean isRespostaCorreta(char marcada) {
        return Character.toUpperCase(marcada) == alternativaCorreta;
    }

    public String getFenInicial() { return fenInicial; }
    public void setFenInicial(String fenInicial) { this.fenInicial = fenInicial; }
}
