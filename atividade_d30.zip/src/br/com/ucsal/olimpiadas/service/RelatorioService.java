
package br.com.ucsal.olimpiadas.service;

import br.com.ucsal.olimpiadas.Tentativa;

public class RelatorioService {

    public void imprimirResultado(Tentativa tentativa, double nota) {
        System.out.println("Participante: " + tentativa.getParticipante().getNome());
        System.out.println("Nota: " + nota);
    }
}
