
package br.com.ucsal.olimpiadas.service;

import br.com.ucsal.olimpiadas.Tentativa;

public class ResultadoService {
    private CalculadoraNota calculadora;

    public ResultadoService(CalculadoraNota calculadora) {
        this.calculadora = calculadora;
    }

    public double calcularNota(Tentativa tentativa) {
        return calculadora.calcular(tentativa);
    }
}
