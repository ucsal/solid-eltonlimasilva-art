package br.com.ucsal.olimpiadas;

import java.util.*;
import br.com.ucsal.olimpiadas.service.*;
import br.com.ucsal.olimpiadas.service.CalculadoraNota;
import br.com.ucsal.olimpiadas.service.CalculadoraNotaPadrao;
public class App {
	static CalculadoraNota calculadora = new CalculadoraNotaPadrao();

    static List<Participante> participantes = new ArrayList<>();
    static List<Prova> provas = new ArrayList<>();
    static List<Questao> questoes = new ArrayList<>();
    static List<Tentativa> tentativas = new ArrayList<>();

    static long id = 1;
    static Scanner in = new Scanner(System.in);

    static CalculadoraNota calculadora = new CalculadoraNotaPadrao();

    public static void main(String[] args) {

        while (true) {
            System.out.println("1- Participante | 2- Prova | 3- Sair");
            switch (in.nextLine()) {
                case "1" -> cadastrarParticipante();
                case "2" -> cadastrarProva();
                case "3" -> { return; }
            }
        }
    }

    static void cadastrarParticipante() {
        Participante p = new Participante();
        p.setId(id++);
        p.setNome("Teste");
        participantes.add(p);
    }

    static void cadastrarProva() {
        Prova p = new Prova();
        p.setId(id++);
        p.setTitulo("Prova");
        provas.add(p);
    }
}
