
# Refatoração - Sistema das Olimpíadas

## Objetivo
Aplicar princípios SOLID sem alterar o comportamento do sistema.

---

## Princípios aplicados

### SRP
Separação de responsabilidades em serviços:
- ResultadoService
- RelatorioService

---

### OCP
Uso da interface CalculadoraNota permitindo novas regras de cálculo sem alterar código existente.

---

### LSP
Garantia de uso correto das implementações de CalculadoraNota.

---

### ISP
Separação de responsabilidades em serviços menores.

---

### DIP
Injeção de dependência da CalculadoraNota no ResultadoService.

---

## Observações
- Nenhuma funcionalidade foi removida
- Código organizado e desacoplado
- Sem uso de frameworks
